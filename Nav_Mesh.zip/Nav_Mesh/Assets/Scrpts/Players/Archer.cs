﻿using UnityEngine;
using System.Collections;

public class Archer: MonoBehaviour {
    public float Health = 100.0f;
    public GameObject playerParent;

	// Use this for initialization
	void Start () {
        //playerParent = GameObject.Find
        //playerParent.transform.parent =
        //Health = 100.0f;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
